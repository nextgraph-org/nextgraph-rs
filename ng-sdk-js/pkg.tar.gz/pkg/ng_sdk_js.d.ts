/* tslint:disable */
/* eslint-disable */
/**
* @param {string} location
* @param {any} invite
* @returns {Promise<any>}
*/
export function get_local_bootstrap(location: string, invite: any): Promise<any>;
/**
* @param {string} invite
* @returns {Promise<any>}
*/
export function decode_invitation(invite: string): Promise<any>;
/**
* @param {string} location
* @returns {Promise<any>}
*/
export function get_local_url(location: string): Promise<any>;
/**
* @param {string} invitation_string
* @returns {Promise<any>}
*/
export function get_ngone_url_of_invitation(invitation_string: string): Promise<any>;
/**
* @param {string} location
* @param {any} invite
* @returns {Promise<any>}
*/
export function get_local_bootstrap_with_public(location: string, invite: any): Promise<any>;
/**
* @param {number} pazzle_length
* @returns {any}
*/
export function wallet_gen_shuffle_for_pazzle_opening(pazzle_length: number): any;
/**
* @returns {Uint8Array}
*/
export function wallet_gen_shuffle_for_pin(): Uint8Array;
/**
* @param {any} js_wallet
* @param {Uint8Array} pazzle
* @param {any} js_pin
* @returns {any}
*/
export function wallet_open_wallet_with_pazzle(js_wallet: any, pazzle: Uint8Array, js_pin: any): any;
/**
* @param {any} js_wallet_id
* @param {any} js_operations
* @returns {any}
*/
export function wallet_update(js_wallet_id: any, js_operations: any): any;
/**
* @returns {any}
*/
export function get_wallets_from_localstorage(): any;
/**
* @param {string} id
* @param {any} key_js
* @param {any} user_js
* @returns {any}
*/
export function get_local_session(id: string, key_js: any, user_js: any): any;
/**
* @param {any} js_params
* @returns {Promise<any>}
*/
export function wallet_create_wallet(js_params: any): Promise<any>;
/**
* @returns {any}
*/
export function test_create_wallet(): any;
/**
* @param {any} payload
* @returns {any}
*/
export function encode_create_account(payload: any): any;
/**
* @returns {any}
*/
export function client_info(): any;
/**
* @returns {Promise<void>}
*/
export function test(): Promise<void>;
/**
* @param {string} nuri
* @param {any} obj_ref_js
* @returns {Promise<any>}
*/
export function doc_get_file_from_store_with_object_ref(nuri: string, obj_ref_js: any): Promise<any>;
/**
* @param {string} anuri
* @param {Function} callback
* @returns {Promise<any>}
*/
export function doc_sync_branch(anuri: string, callback: Function): Promise<any>;
/**
* @returns {Promise<void>}
*/
export function probe(): Promise<void>;
/**
* @returns {Promise<void>}
*/
export function start(): Promise<void>;
/**
* @param {string} name
* @returns {any}
*/
export function change(name: string): any;
