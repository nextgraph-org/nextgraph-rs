import * as wasm from "./ng_sdk_js_bg.wasm";
import { __wbg_set_wasm } from "./ng_sdk_js_bg.js";
__wbg_set_wasm(wasm);
export * from "./ng_sdk_js_bg.js";
